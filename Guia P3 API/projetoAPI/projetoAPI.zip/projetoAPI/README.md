# projetoAPI
Projeto de Teste

Projeto API de Estudo 

Projeto feito passo a passo e está no Youtube
[Link do canal no youtube](https://www.youtube.com/playlist?list=PLC8TqXFuvRUQt9fX5qeqjuGxuo_dM9Wvv)
